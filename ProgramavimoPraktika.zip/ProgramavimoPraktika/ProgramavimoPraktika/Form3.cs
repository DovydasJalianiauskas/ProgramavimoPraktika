﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProgramavimoPraktika
{
    public partial class Form3 : Form
    {

        private int privilege;
        private int userGroupID;

        public Form3(int userGroupID, int privilege)
        {
            InitializeComponent();
            this.privilege = privilege;
            this.userGroupID = userGroupID;
        }

        private void register_button_Click(object sender, EventArgs e)
        {
            string newUsername = new_username.Text;
            string newPassword = new_password.Text;
            string newPrivilege = new_p_group.Text;
            string newUserGroup = new_u_group.Text;

            if (string.IsNullOrEmpty(newUsername) || string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(newPrivilege) || string.IsNullOrEmpty(newUserGroup))
            {
                MessageBox.Show("All fields must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (newPrivilege != "2" && newPrivilege != "3")
            {
                MessageBox.Show("Invalid privilege group ID. It should be either 2 or 3.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!UserGroupExists(newUserGroup))
            {
                MessageBox.Show("No User Group with that ID exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string getMaxUserIdQuery = "SELECT COALESCE(MAX(UserID), 0) FROM users";
                    int maxUserId = 0;
                    using (MySqlCommand getMaxUserIdCommand = new MySqlCommand(getMaxUserIdQuery, connection))
                    {
                        maxUserId = Convert.ToInt32(getMaxUserIdCommand.ExecuteScalar());
                    }

                    int newUserId = maxUserId + 1;

                    string insertQuery = "INSERT INTO users (UserID, Username, Password, Privilege, UserGroupID) VALUES (@UserID, @Username, @Password, @Privilege, @UserGroupID)";
                    using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@UserID", newUserId);
                        command.Parameters.AddWithValue("@Username", newUsername);
                        command.Parameters.AddWithValue("@Password", newPassword);
                        command.Parameters.AddWithValue("@Privilege", newPrivilege);
                        command.Parameters.AddWithValue("@UserGroupID", newUserGroup);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Registration successful!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private bool UserGroupExists(string userGroupID)
        {
            string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM usergroups WHERE UserGroupID = @UserGroupID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserGroupID", userGroupID);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private void logout_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(userGroupID, privilege);
            form2.Show();
            this.Close();
        }
    }
}