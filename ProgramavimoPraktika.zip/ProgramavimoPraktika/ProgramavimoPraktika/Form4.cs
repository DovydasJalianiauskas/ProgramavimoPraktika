﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProgramavimoPraktika
{
    public partial class Form4 : Form
    {

        private int privilege;
        private int userGroupID;
        private string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

        public Form4(int userGroupID, int privilege)
        {
            InitializeComponent();
            LoadUserGroups();
            this.privilege = privilege;
            this.userGroupID = userGroupID;
            delete_u_group_button.Enabled = privilege == 1;
        }

        private void LoadUserGroups()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM usergroups";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable userGroupsTable = new DataTable();
                            adapter.Fill(userGroupsTable);
                            user_groups_view.DataSource = userGroupsTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void create_u_group_buton_Click(object sender, EventArgs e)
        {
            string locationValue = location.Text;
            if (string.IsNullOrEmpty(locationValue))
            {
                MessageBox.Show("Location field must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (UserGroupLocationExists(locationValue))
            {
                MessageBox.Show("Location already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int lastUserGroupID = GetLastUserGroupID();
            int newUserGroupID = lastUserGroupID + 1;
            InsertUserGroup(newUserGroupID, locationValue);
            LoadUserGroups();

            MessageBox.Show("User group created successfully!");
        }

        private bool UserGroupLocationExists(string location)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM usergroups WHERE Location = @Location";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Location", location);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private int GetLastUserGroupID()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COALESCE(MAX(UserGroupID), 0) FROM usergroups";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        private void InsertUserGroup(int userGroupID, string location)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "INSERT INTO usergroups (UserGroupID, Location) VALUES (@UserGroupID, @Location)";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserGroupID", userGroupID);
                        command.Parameters.AddWithValue("@Location", location);

                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void delete_u_group_button_Click(object sender, EventArgs e)
        {
            string userGroupIDString = user_group_id.Text;
            if (string.IsNullOrEmpty(userGroupIDString))
            {
                MessageBox.Show("User Group ID must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(userGroupIDString, out int userGroupID))
            {
                MessageBox.Show("Invalid User Group ID. It must be a numeric value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!UserGroupIDExists(userGroupID))
            {
                MessageBox.Show("User Group ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this User Group?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DeleteUserGroup(userGroupID);
                LoadUserGroups();

                MessageBox.Show("User Group deleted successfully!");
            }
        }

        private bool UserGroupIDExists(int userGroupID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM usergroups WHERE UserGroupID = @UserGroupID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserGroupID", userGroupID);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private void DeleteUserGroup(int userGroupID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string servicesQuery = "DELETE FROM services WHERE UserGroupID = @UserGroupID";
                using (MySqlCommand servicesCommand = new MySqlCommand(servicesQuery, connection))
                {
                    servicesCommand.Parameters.AddWithValue("@UserGroupID", userGroupID);
                    servicesCommand.ExecuteNonQuery();
                }

                string userGroupQuery = "DELETE FROM usergroups WHERE UserGroupID = @UserGroupID";
                using (MySqlCommand userGroupCommand = new MySqlCommand(userGroupQuery, connection))
                {
                    userGroupCommand.Parameters.AddWithValue("@UserGroupID", userGroupID);
                    userGroupCommand.ExecuteNonQuery();
                }
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void logout_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(userGroupID, privilege);
            form2.Show();
            this.Close();
        }
    }
}