﻿namespace ProgramavimoPraktika
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            label10 = new Label();
            logout_button = new Button();
            back_button = new Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            services_view = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            add_service_name = new TextBox();
            add_ugroup_id = new TextBox();
            change_price = new TextBox();
            add_service_button = new Button();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            change_service_id = new TextBox();
            label11 = new Label();
            label12 = new Label();
            add_service_price = new TextBox();
            change_price_button = new Button();
            delete_service_button = new Button();
            label14 = new Label();
            delete_service_id = new TextBox();
            label15 = new Label();
            ((System.ComponentModel.ISupportInitialize)services_view).BeginInit();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(291, 16);
            label10.Name = "label10";
            label10.Size = new Size(600, 25);
            label10.TabIndex = 28;
            label10.Text = "Service Tax System - everything in one place for your convenience";
            // 
            // logout_button
            // 
            logout_button.Location = new Point(1016, 8);
            logout_button.Name = "logout_button";
            logout_button.Size = new Size(113, 47);
            logout_button.TabIndex = 27;
            logout_button.Text = "Log out";
            logout_button.UseVisualStyleBackColor = true;
            logout_button.Click += logout_button_Click;
            // 
            // back_button
            // 
            back_button.Location = new Point(69, 8);
            back_button.Name = "back_button";
            back_button.Size = new Size(113, 47);
            back_button.TabIndex = 26;
            back_button.Text = "Back";
            back_button.UseVisualStyleBackColor = true;
            back_button.Click += back_button_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(-8, 54);
            label9.Name = "label9";
            label9.Size = new Size(1212, 15);
            label9.TabIndex = 25;
            label9.Text = resources.GetString("label9.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(39, 611);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 30;
            label8.Text = "System is owned by StudentsTM";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(-8, 580);
            label7.Name = "label7";
            label7.Size = new Size(1212, 15);
            label7.TabIndex = 29;
            label7.Text = resources.GetString("label7.Text");
            // 
            // services_view
            // 
            services_view.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            services_view.Location = new Point(335, 123);
            services_view.Name = "services_view";
            services_view.RowTemplate.Height = 25;
            services_view.Size = new Size(508, 179);
            services_view.TabIndex = 31;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(465, 83);
            label1.Name = "label1";
            label1.Size = new Size(253, 25);
            label1.TabIndex = 32;
            label1.Text = "Services are displayed below";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(221, 322);
            label2.Name = "label2";
            label2.Size = new Size(224, 21);
            label2.TabIndex = 33;
            label2.Text = "Add service for a user group";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(579, 322);
            label3.Name = "label3";
            label3.Size = new Size(168, 21);
            label3.TabIndex = 34;
            label3.Text = "Change service price";
            // 
            // add_service_name
            // 
            add_service_name.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            add_service_name.Location = new Point(197, 360);
            add_service_name.Multiline = true;
            add_service_name.Name = "add_service_name";
            add_service_name.Size = new Size(269, 38);
            add_service_name.TabIndex = 35;
            // 
            // add_ugroup_id
            // 
            add_ugroup_id.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            add_ugroup_id.Location = new Point(197, 468);
            add_ugroup_id.Multiline = true;
            add_ugroup_id.Name = "add_ugroup_id";
            add_ugroup_id.Size = new Size(68, 38);
            add_ugroup_id.TabIndex = 36;
            // 
            // change_price
            // 
            change_price.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            change_price.Location = new Point(664, 432);
            change_price.Multiline = true;
            change_price.Name = "change_price";
            change_price.Size = new Size(94, 38);
            change_price.TabIndex = 37;
            // 
            // add_service_button
            // 
            add_service_button.Location = new Point(270, 516);
            add_service_button.Name = "add_service_button";
            add_service_button.Size = new Size(113, 47);
            add_service_button.TabIndex = 38;
            add_service_button.Text = "Add";
            add_service_button.UseVisualStyleBackColor = true;
            add_service_button.Click += add_service_button_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(69, 360);
            label4.Name = "label4";
            label4.Size = new Size(122, 21);
            label4.TabIndex = 39;
            label4.Text = "Name of service";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(75, 415);
            label5.Name = "label5";
            label5.Size = new Size(114, 21);
            label5.TabIndex = 40;
            label5.Text = "Price of service";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(82, 468);
            label6.Name = "label6";
            label6.Size = new Size(107, 21);
            label6.TabIndex = 41;
            label6.Text = "User group ID";
            // 
            // change_service_id
            // 
            change_service_id.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            change_service_id.Location = new Point(664, 377);
            change_service_id.Multiline = true;
            change_service_id.Name = "change_service_id";
            change_service_id.Size = new Size(68, 38);
            change_service_id.TabIndex = 42;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(579, 377);
            label11.Name = "label11";
            label11.Size = new Size(79, 21);
            label11.TabIndex = 43;
            label11.Text = "Service ID";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(526, 428);
            label12.Name = "label12";
            label12.Size = new Size(132, 21);
            label12.TabIndex = 44;
            label12.Text = "New service price";
            // 
            // add_service_price
            // 
            add_service_price.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            add_service_price.Location = new Point(197, 415);
            add_service_price.Multiline = true;
            add_service_price.Name = "add_service_price";
            add_service_price.Size = new Size(94, 38);
            add_service_price.TabIndex = 45;
            // 
            // change_price_button
            // 
            change_price_button.Location = new Point(605, 516);
            change_price_button.Name = "change_price_button";
            change_price_button.Size = new Size(113, 47);
            change_price_button.TabIndex = 46;
            change_price_button.Text = "Change";
            change_price_button.UseVisualStyleBackColor = true;
            change_price_button.Click += change_price_button_Click;
            // 
            // delete_service_button
            // 
            delete_service_button.Location = new Point(911, 514);
            delete_service_button.Name = "delete_service_button";
            delete_service_button.Size = new Size(113, 47);
            delete_service_button.TabIndex = 52;
            delete_service_button.Text = "Delete";
            delete_service_button.UseVisualStyleBackColor = true;
            delete_service_button.Click += delete_service_button_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(871, 411);
            label14.Name = "label14";
            label14.Size = new Size(79, 21);
            label14.TabIndex = 50;
            label14.Text = "Service ID";
            // 
            // delete_service_id
            // 
            delete_service_id.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            delete_service_id.Location = new Point(956, 411);
            delete_service_id.Multiline = true;
            delete_service_id.Name = "delete_service_id";
            delete_service_id.Size = new Size(68, 38);
            delete_service_id.TabIndex = 49;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label15.Location = new Point(892, 320);
            label15.Name = "label15";
            label15.Size = new Size(118, 21);
            label15.TabIndex = 47;
            label15.Text = "Delete service";
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1151, 654);
            Controls.Add(delete_service_button);
            Controls.Add(label14);
            Controls.Add(delete_service_id);
            Controls.Add(label15);
            Controls.Add(change_price_button);
            Controls.Add(add_service_price);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(change_service_id);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(add_service_button);
            Controls.Add(change_price);
            Controls.Add(add_ugroup_id);
            Controls.Add(add_service_name);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(services_view);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label10);
            Controls.Add(logout_button);
            Controls.Add(back_button);
            Controls.Add(label9);
            Name = "Form6";
            Text = "Form6";
            ((System.ComponentModel.ISupportInitialize)services_view).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private Button logout_button;
        private Button back_button;
        private Label label9;
        private Label label8;
        private Label label7;
        private DataGridView services_view;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox add_service_name;
        private TextBox add_ugroup_id;
        private TextBox change_price;
        private Button add_service_button;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox change_service_id;
        private Label label11;
        private Label label12;
        private TextBox add_service_price;
        private Button change_price_button;
        private Button delete_service_button;
        private Label label14;
        private TextBox delete_service_id;
        private Label label15;
    }
}