﻿namespace ProgramavimoPraktika
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            label10 = new Label();
            logout_button = new Button();
            back_button = new Button();
            label9 = new Label();
            label8 = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            create_u_group_buton = new Button();
            label4 = new Label();
            user_group_id = new TextBox();
            label5 = new Label();
            label7 = new Label();
            user_groups_view = new DataGridView();
            location = new TextBox();
            label6 = new Label();
            delete_u_group_button = new Button();
            ((System.ComponentModel.ISupportInitialize)user_groups_view).BeginInit();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(133, 20);
            label10.Name = "label10";
            label10.Size = new Size(600, 25);
            label10.TabIndex = 20;
            label10.Text = "Service Tax System - everything in one place for your convenience";
            // 
            // logout_button
            // 
            logout_button.Location = new Point(761, 9);
            logout_button.Name = "logout_button";
            logout_button.Size = new Size(113, 47);
            logout_button.TabIndex = 19;
            logout_button.Text = "Log out";
            logout_button.UseVisualStyleBackColor = true;
            logout_button.Click += logout_button_Click;
            // 
            // back_button
            // 
            back_button.Location = new Point(9, 9);
            back_button.Name = "back_button";
            back_button.Size = new Size(113, 47);
            back_button.TabIndex = 18;
            back_button.Text = "Back";
            back_button.UseVisualStyleBackColor = true;
            back_button.Click += back_button_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(-68, 55);
            label9.Name = "label9";
            label9.Size = new Size(1067, 15);
            label9.TabIndex = 17;
            label9.Text = resources.GetString("label9.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(42, 500);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 22;
            label8.Text = "System is owned by StudentsTM";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(367, 113);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 23;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(186, 312);
            label2.Name = "label2";
            label2.Size = new Size(181, 21);
            label2.TabIndex = 24;
            label2.Text = "Create new user group";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(120, 359);
            label3.Name = "label3";
            label3.Size = new Size(69, 21);
            label3.TabIndex = 27;
            label3.Text = "Location";
            // 
            // create_u_group_buton
            // 
            create_u_group_buton.Location = new Point(205, 414);
            create_u_group_buton.Name = "create_u_group_buton";
            create_u_group_buton.Size = new Size(113, 45);
            create_u_group_buton.TabIndex = 28;
            create_u_group_buton.Text = "Create";
            create_u_group_buton.UseVisualStyleBackColor = true;
            create_u_group_buton.Click += create_u_group_buton_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(535, 314);
            label4.Name = "label4";
            label4.Size = new Size(146, 21);
            label4.TabIndex = 29;
            label4.Text = "Delete user group";
            // 
            // user_group_id
            // 
            user_group_id.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            user_group_id.Location = new Point(581, 358);
            user_group_id.Multiline = true;
            user_group_id.Name = "user_group_id";
            user_group_id.Size = new Size(68, 37);
            user_group_id.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(466, 361);
            label5.Name = "label5";
            label5.Size = new Size(109, 21);
            label5.TabIndex = 34;
            label5.Text = "User Group ID";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(-5, 469);
            label7.Name = "label7";
            label7.Size = new Size(1067, 15);
            label7.TabIndex = 21;
            label7.Text = resources.GetString("label7.Text");
            // 
            // user_groups_view
            // 
            user_groups_view.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            user_groups_view.Location = new Point(258, 154);
            user_groups_view.Name = "user_groups_view";
            user_groups_view.RowTemplate.Height = 25;
            user_groups_view.Size = new Size(349, 139);
            user_groups_view.TabIndex = 36;
            // 
            // location
            // 
            location.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            location.Location = new Point(195, 361);
            location.Multiline = true;
            location.Name = "location";
            location.Size = new Size(210, 37);
            location.TabIndex = 37;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(213, 87);
            label6.Name = "label6";
            label6.Size = new Size(436, 50);
            label6.TabIndex = 38;
            label6.Text = "All user groups are displayed below.\r\nCreate a new user group or delete an existing one.";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // delete_u_group_button
            // 
            delete_u_group_button.Location = new Point(557, 414);
            delete_u_group_button.Name = "delete_u_group_button";
            delete_u_group_button.Size = new Size(113, 45);
            delete_u_group_button.TabIndex = 39;
            delete_u_group_button.Text = "Delete";
            delete_u_group_button.UseVisualStyleBackColor = true;
            delete_u_group_button.Click += delete_u_group_button_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(901, 548);
            Controls.Add(delete_u_group_button);
            Controls.Add(label6);
            Controls.Add(location);
            Controls.Add(user_groups_view);
            Controls.Add(label5);
            Controls.Add(user_group_id);
            Controls.Add(label4);
            Controls.Add(create_u_group_buton);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label10);
            Controls.Add(logout_button);
            Controls.Add(back_button);
            Controls.Add(label9);
            Name = "Form4";
            Text = "Form4";
            Load += Form4_Load;
            ((System.ComponentModel.ISupportInitialize)user_groups_view).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private Button logout_button;
        private Button back_button;
        private Label label9;
        private Label label8;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button create_u_group_buton;
        private Label label4;
        private TextBox user_group_id;
        private Label label5;
        private Label label7;
        private DataGridView user_groups_view;
        private TextBox location;
        private Label label6;
        private Button delete_u_group_button;
    }
}