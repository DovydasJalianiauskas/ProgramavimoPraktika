﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProgramavimoPraktika
{
    public partial class Form6 : Form
    {
        private int privilege;
        private int userGroupID;
        private string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

        public Form6(int userGroupID, int privilege)
        {
            InitializeComponent();
            LoadServicesData();
            this.privilege = privilege;
            this.userGroupID = userGroupID;
            delete_service_button.Enabled = privilege == 1;
        }

        private void LoadServicesData()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM services";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable servicesTable = new DataTable();
                            adapter.Fill(servicesTable);
                            services_view.DataSource = servicesTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void add_service_button_Click(object sender, EventArgs e)
        {
            string serviceName = add_service_name.Text;
            string serviceCostString = add_service_price.Text;
            string userGroupIDString = add_ugroup_id.Text;

            if (string.IsNullOrEmpty(serviceName) || string.IsNullOrEmpty(serviceCostString) || string.IsNullOrEmpty(userGroupIDString))
            {
                MessageBox.Show("Service Name, Service Cost, and User Group ID must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (!decimal.TryParse(serviceCostString, out decimal serviceCost))
            {
                MessageBox.Show("Invalid Service Cost.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(userGroupIDString, out int userGroupID))
            {
                MessageBox.Show("Invalid User Group ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidUserGroupID(userGroupID))
            {
                MessageBox.Show("Invalid User Group ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to add this service?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                AddService(serviceName, serviceCost, userGroupID);
                LoadServicesData();

                MessageBox.Show("Service added successfully!");
            }
        }

        private int GetLatestUserGroupID()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT MAX(UserGroupID) FROM usergroups";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    object result = command.ExecuteScalar();
                    return result == DBNull.Value ? 0 : Convert.ToInt32(result);
                }
            }
        }

        private bool IsValidUserGroupID(int userGroupID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM usergroups WHERE UserGroupID = @UserGroupID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserGroupID", userGroupID);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private void AddService(string serviceName, decimal serviceCost, int userGroupID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO services (ServiceName, ServiceCost, UserGroupID) VALUES (@ServiceName, @ServiceCost, @UserGroupID)";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ServiceName", serviceName);
                    command.Parameters.AddWithValue("@ServiceCost", serviceCost);
                    command.Parameters.AddWithValue("@UserGroupID", userGroupID);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void change_price_button_Click(object sender, EventArgs e)
        {
            string serviceIDString = change_service_id.Text;
            string newServiceCostString = change_price.Text;

            if (string.IsNullOrEmpty(serviceIDString) || string.IsNullOrEmpty(newServiceCostString))
            {
                MessageBox.Show("Service ID and New Service Cost must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(serviceIDString, out int serviceID) || !decimal.TryParse(newServiceCostString, out decimal newServiceCost))
            {
                MessageBox.Show("Invalid Service ID or New Service Cost. They must be numeric values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!ServiceIDExists(serviceID))
            {
                MessageBox.Show("Service ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to modify the service price?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                ModifyServicePrice(serviceID, newServiceCost);

                LoadServicesData();

                MessageBox.Show("Service price modified successfully!");
            }
        }

        private bool ServiceIDExists(int serviceID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM services WHERE ServiceID = @ServiceID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ServiceID", serviceID);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private void ModifyServicePrice(int serviceID, decimal newServiceCost)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "UPDATE services SET ServiceCost = @NewServiceCost WHERE ServiceID = @ServiceID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NewServiceCost", newServiceCost);
                    command.Parameters.AddWithValue("@ServiceID", serviceID);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void delete_service_button_Click(object sender, EventArgs e)
        {
            string serviceIDString = delete_service_id.Text;

            if (string.IsNullOrEmpty(serviceIDString))
            {
                MessageBox.Show("Service ID must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(serviceIDString, out int serviceID))
            {
                MessageBox.Show("Invalid Service ID. It must be a numeric value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!ServiceIDExists(serviceID))
            {
                MessageBox.Show("Service ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this service?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DeleteService(serviceID);
                LoadServicesData();

                MessageBox.Show("Service deleted successfully!");
            }
        }

        private void DeleteService(int serviceID)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM services WHERE ServiceID = @ServiceID";
                using (MySqlCommand deleteCommand = new MySqlCommand(deleteQuery, connection))
                {
                    deleteCommand.Parameters.AddWithValue("@ServiceID", serviceID);
                    deleteCommand.ExecuteNonQuery();
                }
            }
        }

        private void logout_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(userGroupID, privilege);
            form2.Show();
            this.Close();
        }
    }
}