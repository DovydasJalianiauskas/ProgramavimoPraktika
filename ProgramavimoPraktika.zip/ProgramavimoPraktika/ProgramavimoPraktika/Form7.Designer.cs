﻿namespace ProgramavimoPraktika
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            label10 = new Label();
            logout_button = new Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label1 = new Label();
            user_service_view = new DataGridView();
            back = new Button();
            ((System.ComponentModel.ISupportInitialize)user_service_view).BeginInit();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(149, 20);
            label10.Name = "label10";
            label10.Size = new Size(600, 25);
            label10.TabIndex = 28;
            label10.Text = "Service Tax System - everything in one place for your convenience";
            // 
            // logout_button
            // 
            logout_button.Location = new Point(755, 12);
            logout_button.Name = "logout_button";
            logout_button.Size = new Size(113, 47);
            logout_button.TabIndex = 27;
            logout_button.Text = "Log out";
            logout_button.UseVisualStyleBackColor = true;
            logout_button.Click += logout_button_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(-41, 56);
            label9.Name = "label9";
            label9.Size = new Size(1067, 15);
            label9.TabIndex = 25;
            label9.Text = resources.GetString("label9.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(37, 484);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 30;
            label8.Text = "System is owned by StudentsTM";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(-10, 453);
            label7.Name = "label7";
            label7.Size = new Size(1067, 15);
            label7.TabIndex = 29;
            label7.Text = resources.GetString("label7.Text");
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(176, 92);
            label1.Name = "label1";
            label1.Size = new Size(609, 50);
            label1.TabIndex = 31;
            label1.Text = "Services and their fees are provided below. \r\nYou can only see the services that are for the user group you belong to.";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // user_service_view
            // 
            user_service_view.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            user_service_view.Location = new Point(256, 186);
            user_service_view.Name = "user_service_view";
            user_service_view.RowTemplate.Height = 25;
            user_service_view.Size = new Size(439, 204);
            user_service_view.TabIndex = 32;
            // 
            // back
            // 
            back.Location = new Point(21, 12);
            back.Name = "back";
            back.Size = new Size(113, 47);
            back.TabIndex = 33;
            back.Text = "Back";
            back.UseVisualStyleBackColor = true;
            back.Click += back_Click;
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(962, 533);
            Controls.Add(back);
            Controls.Add(user_service_view);
            Controls.Add(label1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label10);
            Controls.Add(logout_button);
            Controls.Add(label9);
            Name = "Form7";
            Text = "Form7";
            ((System.ComponentModel.ISupportInitialize)user_service_view).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private Button logout_button;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label1;
        private DataGridView user_service_view;
        private Button back;
    }
}