﻿namespace ProgramavimoPraktika
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            new_username = new TextBox();
            new_password = new TextBox();
            new_p_group = new TextBox();
            register_button = new Button();
            label1 = new Label();
            label2 = new Label();
            new_u_group = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            back_button = new Button();
            logout_button = new Button();
            label10 = new Label();
            SuspendLayout();
            // 
            // new_username
            // 
            new_username.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            new_username.Location = new Point(246, 148);
            new_username.Multiline = true;
            new_username.Name = "new_username";
            new_username.Size = new Size(271, 37);
            new_username.TabIndex = 0;
            // 
            // new_password
            // 
            new_password.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            new_password.Location = new Point(246, 202);
            new_password.Multiline = true;
            new_password.Name = "new_password";
            new_password.Size = new Size(271, 37);
            new_password.TabIndex = 1;
            // 
            // new_p_group
            // 
            new_p_group.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            new_p_group.Location = new Point(339, 256);
            new_p_group.Multiline = true;
            new_p_group.Name = "new_p_group";
            new_p_group.Size = new Size(85, 37);
            new_p_group.TabIndex = 2;
            // 
            // register_button
            // 
            register_button.Location = new Point(327, 363);
            register_button.Name = "register_button";
            register_button.Size = new Size(113, 47);
            register_button.TabIndex = 3;
            register_button.Text = "Register";
            register_button.UseVisualStyleBackColor = true;
            register_button.Click += register_button_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(64, 92);
            label1.Name = "label1";
            label1.Size = new Size(761, 25);
            label1.TabIndex = 4;
            label1.Text = "Create a new user by entering their username, password, privilege group and user group.";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(583, 195);
            label2.Name = "label2";
            label2.Size = new Size(206, 135);
            label2.TabIndex = 5;
            label2.Text = "Legend:\r\nUsername = user's first name.\r\nPassword = user's last name.\r\n\r\nPrivileged group Legend:\r\n2 - Manager\r\n3 - Regular user\r\n\r\nUser Group = ID of desired user group";
            // 
            // new_u_group
            // 
            new_u_group.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            new_u_group.Location = new Point(339, 311);
            new_u_group.Multiline = true;
            new_u_group.Name = "new_u_group";
            new_u_group.Size = new Size(85, 37);
            new_u_group.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(159, 148);
            label3.Name = "label3";
            label3.Size = new Size(81, 21);
            label3.TabIndex = 7;
            label3.Text = "Username";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(164, 200);
            label4.Name = "label4";
            label4.Size = new Size(76, 21);
            label4.TabIndex = 8;
            label4.Text = "Password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(217, 254);
            label5.Name = "label5";
            label5.Size = new Size(116, 21);
            label5.TabIndex = 9;
            label5.Text = "Privilege group";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(245, 309);
            label6.Name = "label6";
            label6.Size = new Size(88, 21);
            label6.TabIndex = 10;
            label6.Text = "User group";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(0, 434);
            label7.Name = "label7";
            label7.Size = new Size(1067, 15);
            label7.TabIndex = 11;
            label7.Text = resources.GetString("label7.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(47, 465);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 12;
            label8.Text = "System is owned by StudentsTM";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(-65, 51);
            label9.Name = "label9";
            label9.Size = new Size(1067, 15);
            label9.TabIndex = 13;
            label9.Text = resources.GetString("label9.Text");
            // 
            // back_button
            // 
            back_button.Location = new Point(12, 5);
            back_button.Name = "back_button";
            back_button.Size = new Size(113, 47);
            back_button.TabIndex = 14;
            back_button.Text = "Back";
            back_button.UseVisualStyleBackColor = true;
            back_button.Click += back_button_Click;
            // 
            // logout_button
            // 
            logout_button.Location = new Point(743, 5);
            logout_button.Name = "logout_button";
            logout_button.Size = new Size(113, 47);
            logout_button.TabIndex = 15;
            logout_button.Text = "Log out";
            logout_button.UseVisualStyleBackColor = true;
            logout_button.Click += logout_button_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(136, 16);
            label10.Name = "label10";
            label10.Size = new Size(600, 25);
            label10.TabIndex = 16;
            label10.Text = "Service Tax System - everything in one place for your convenience";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(868, 502);
            Controls.Add(label10);
            Controls.Add(logout_button);
            Controls.Add(back_button);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(new_u_group);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(register_button);
            Controls.Add(new_p_group);
            Controls.Add(new_password);
            Controls.Add(new_username);
            Name = "Form3";
            Text = "Form3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox new_username;
        private TextBox new_password;
        private TextBox new_p_group;
        private Button register_button;
        private Label label1;
        private Label label2;
        private TextBox new_u_group;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button back_button;
        private Button logout_button;
        private Label label10;
    }
}