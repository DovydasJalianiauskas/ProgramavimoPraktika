﻿namespace ProgramavimoPraktika
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            username_login = new TextBox();
            password_login = new TextBox();
            login_button = new Button();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(238, 21);
            label1.Name = "label1";
            label1.Size = new Size(314, 100);
            label1.TabIndex = 0;
            label1.Text = "Welcome!\r\nPlease log in to the system \r\nby entering your name as username\r\nand your surname as password.";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // username_login
            // 
            username_login.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            username_login.Location = new Point(247, 163);
            username_login.Multiline = true;
            username_login.Name = "username_login";
            username_login.Size = new Size(330, 38);
            username_login.TabIndex = 1;
            // 
            // password_login
            // 
            password_login.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            password_login.Location = new Point(247, 247);
            password_login.Multiline = true;
            password_login.Name = "password_login";
            password_login.Size = new Size(330, 38);
            password_login.TabIndex = 2;
            // 
            // login_button
            // 
            login_button.Location = new Point(340, 313);
            login_button.Name = "login_button";
            login_button.Size = new Size(107, 46);
            login_button.TabIndex = 3;
            login_button.Text = "Log in";
            login_button.UseVisualStyleBackColor = true;
            login_button.Click += login_button_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(144, 163);
            label2.Name = "label2";
            label2.Size = new Size(97, 25);
            label2.TabIndex = 4;
            label2.Text = "Username";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(150, 242);
            label3.Name = "label3";
            label3.Size = new Size(91, 25);
            label3.TabIndex = 5;
            label3.Text = "Password";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(744, 409);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(login_button);
            Controls.Add(password_login);
            Controls.Add(username_login);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Log in";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox username_login;
        private TextBox password_login;
        private Button login_button;
        private Label label2;
        private Label label3;
    }
}