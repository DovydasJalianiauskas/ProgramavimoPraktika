using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace ProgramavimoPraktika
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            string enteredUsername = username_login.Text;
            string enteredPassword = password_login.Text;

            string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT COUNT(*), Privilege FROM users WHERE Username = @Username AND Password = @Password";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", enteredUsername);
                        command.Parameters.AddWithValue("@Password", enteredPassword);

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int count = reader.GetInt32(0);

                                if (count > 0)
                                {
                                    MessageBox.Show("Login successful!");

                                    int userGroupID = GetUserGroupID(enteredUsername, enteredPassword);
                                    int privilege = GetPrivilegeNumber(enteredUsername, enteredPassword);

                                    if (privilege == 1 || privilege == 2)
                                    {
                                        Form2 form2 = new Form2(userGroupID, privilege);
                                        form2.Show();
                                    }
                                    else if (privilege == 3)
                                    {
                                        Form7 form7 = new Form7(userGroupID, privilege);
                                        form7.Show();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Invalid username or password. Please try again.");
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private int GetUserGroupID(string username, string password)
        {
            int userGroupID = -1;

            string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT UserGroupID FROM users WHERE Username = @Username AND Password = @Password";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", password);

                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            userGroupID = Convert.ToInt32(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error getting UserGroupID: " + ex.Message);
                }
            }

            return userGroupID;
        }

        private int GetPrivilegeNumber(string username, string password)
        {
            int privilege = -1;

            string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT Privilege FROM users WHERE Username = @Username AND Password = @Password";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", password);

                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            privilege = Convert.ToInt32(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error getting Privilege: " + ex.Message);
                }
            }

            return privilege;
        }
    }
}
