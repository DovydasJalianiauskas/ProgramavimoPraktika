﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgramavimoPraktika
{
    public partial class Form2 : Form
    {
        private int privilege;
        private int userGroupID;
        public Form2(int userGroupID, int privilege)
        {
            InitializeComponent();
            this.privilege = privilege;
            this.userGroupID = userGroupID;
            create_user_button.Enabled = privilege == 1;
            check_button.Enabled = privilege == 2;
        }

        private void create_user_button_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(userGroupID, privilege);
            form3.Show();
            this.Close();
        }

        private void create_user_group_button_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4(userGroupID, privilege);
            form4.Show();
            this.Close();
        }

        private void modify_users_button_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5(userGroupID, privilege);
            form5.Show();
            this.Close();
        }

        private void modify_services_button_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6(userGroupID, privilege);
            form6.Show();
            this.Close();
        }

        private void logout_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void check_button_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7(userGroupID, privilege);
            form7.Show();
            this.Close();
        }
    }
}
