﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace ProgramavimoPraktika
{
    public partial class Form7 : Form
    {
        private int userGroupID;
        private int privilege;

        public Form7(int userGroupID, int privilege)
        {
            InitializeComponent();
            this.userGroupID = userGroupID;
            LoadServicesData();
            this.privilege = privilege;
            back.Enabled = privilege == 2;
        }

        private void LoadServicesData()
        {
            string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM services WHERE UserGroupID = @UserGroupID";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserGroupID", userGroupID);

                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            adapter.Fill(dataTable);

                            user_service_view.DataSource = dataTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading services data: " + ex.Message);
                }
            }
        }

        private void logout_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(userGroupID, privilege);
            form2.Show();
            this.Close();
        }
    }
}
