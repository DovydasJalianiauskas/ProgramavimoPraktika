﻿namespace ProgramavimoPraktika
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            label10 = new Label();
            logout_button = new Button();
            back_button = new Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            user_info_view = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            userid = new TextBox();
            delete_user_button = new Button();
            userid_ug = new TextBox();
            new_ugroup_id = new TextBox();
            label4 = new Label();
            new_pgroup_id = new TextBox();
            userid_pg = new TextBox();
            modify_ugroup_button = new Button();
            modify_pgroup_button = new Button();
            label5 = new Label();
            label6 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            legend = new Label();
            ((System.ComponentModel.ISupportInitialize)user_info_view).BeginInit();
            SuspendLayout();
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(138, 20);
            label10.Name = "label10";
            label10.Size = new Size(600, 25);
            label10.TabIndex = 24;
            label10.Text = "Service Tax System - everything in one place for your convenience";
            // 
            // logout_button
            // 
            logout_button.Location = new Point(766, 9);
            logout_button.Name = "logout_button";
            logout_button.Size = new Size(113, 47);
            logout_button.TabIndex = 23;
            logout_button.Text = "Log out";
            logout_button.UseVisualStyleBackColor = true;
            logout_button.Click += logout_button_Click;
            // 
            // back_button
            // 
            back_button.Location = new Point(14, 9);
            back_button.Name = "back_button";
            back_button.Size = new Size(113, 47);
            back_button.TabIndex = 22;
            back_button.Text = "Back";
            back_button.UseVisualStyleBackColor = true;
            back_button.Click += back_button_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(-63, 55);
            label9.Name = "label9";
            label9.Size = new Size(1067, 15);
            label9.TabIndex = 21;
            label9.Text = resources.GetString("label9.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(39, 525);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 26;
            label8.Text = "System is owned by StudentsTM";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(-8, 494);
            label7.Name = "label7";
            label7.Size = new Size(1067, 15);
            label7.TabIndex = 25;
            label7.Text = resources.GetString("label7.Text");
            // 
            // user_info_view
            // 
            user_info_view.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            user_info_view.Location = new Point(228, 116);
            user_info_view.Name = "user_info_view";
            user_info_view.RowTemplate.Height = 25;
            user_info_view.Size = new Size(419, 153);
            user_info_view.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(280, 79);
            label1.Name = "label1";
            label1.Size = new Size(312, 25);
            label1.TabIndex = 28;
            label1.Text = "User information is provided below.";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(107, 291);
            label2.Name = "label2";
            label2.Size = new Size(96, 21);
            label2.TabIndex = 29;
            label2.Text = "Delete user";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(362, 291);
            label3.Name = "label3";
            label3.Size = new Size(162, 21);
            label3.TabIndex = 30;
            label3.Text = "Modify user's group";
            // 
            // userid
            // 
            userid.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            userid.Location = new Point(123, 328);
            userid.Multiline = true;
            userid.Name = "userid";
            userid.Size = new Size(64, 36);
            userid.TabIndex = 31;
            // 
            // delete_user_button
            // 
            delete_user_button.Location = new Point(98, 382);
            delete_user_button.Name = "delete_user_button";
            delete_user_button.Size = new Size(113, 47);
            delete_user_button.TabIndex = 32;
            delete_user_button.Text = "Delete";
            delete_user_button.UseVisualStyleBackColor = true;
            delete_user_button.Click += delete_user_button_Click;
            // 
            // userid_ug
            // 
            userid_ug.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            userid_ug.Location = new Point(412, 328);
            userid_ug.Multiline = true;
            userid_ug.Name = "userid_ug";
            userid_ug.Size = new Size(64, 36);
            userid_ug.TabIndex = 33;
            // 
            // new_ugroup_id
            // 
            new_ugroup_id.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            new_ugroup_id.Location = new Point(412, 382);
            new_ugroup_id.Multiline = true;
            new_ugroup_id.Name = "new_ugroup_id";
            new_ugroup_id.Size = new Size(64, 36);
            new_ugroup_id.TabIndex = 34;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(630, 291);
            label4.Name = "label4";
            label4.Size = new Size(187, 21);
            label4.TabIndex = 35;
            label4.Text = "Modify privilege group";
            // 
            // new_pgroup_id
            // 
            new_pgroup_id.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            new_pgroup_id.Location = new Point(692, 382);
            new_pgroup_id.Multiline = true;
            new_pgroup_id.Name = "new_pgroup_id";
            new_pgroup_id.Size = new Size(64, 36);
            new_pgroup_id.TabIndex = 37;
            // 
            // userid_pg
            // 
            userid_pg.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            userid_pg.Location = new Point(692, 328);
            userid_pg.Multiline = true;
            userid_pg.Name = "userid_pg";
            userid_pg.Size = new Size(64, 36);
            userid_pg.TabIndex = 36;
            // 
            // modify_ugroup_button
            // 
            modify_ugroup_button.Location = new Point(385, 434);
            modify_ugroup_button.Name = "modify_ugroup_button";
            modify_ugroup_button.Size = new Size(118, 47);
            modify_ugroup_button.TabIndex = 38;
            modify_ugroup_button.Text = "Modify";
            modify_ugroup_button.UseVisualStyleBackColor = true;
            modify_ugroup_button.Click += modify_ugroup_button_Click;
            // 
            // modify_pgroup_button
            // 
            modify_pgroup_button.Location = new Point(665, 434);
            modify_pgroup_button.Name = "modify_pgroup_button";
            modify_pgroup_button.Size = new Size(118, 47);
            modify_pgroup_button.TabIndex = 39;
            modify_pgroup_button.Text = "Modify";
            modify_pgroup_button.UseVisualStyleBackColor = true;
            modify_pgroup_button.Click += modify_pgroup_button_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(56, 328);
            label5.Name = "label5";
            label5.Size = new Size(61, 21);
            label5.TabIndex = 40;
            label5.Text = "User ID";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(345, 328);
            label6.Name = "label6";
            label6.Size = new Size(61, 21);
            label6.TabIndex = 41;
            label6.Text = "User ID";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(299, 382);
            label11.Name = "label11";
            label11.Size = new Size(107, 21);
            label11.TabIndex = 42;
            label11.Text = "New group ID";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(625, 328);
            label12.Name = "label12";
            label12.Size = new Size(61, 21);
            label12.TabIndex = 43;
            label12.Text = "User ID";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(561, 382);
            label13.Name = "label13";
            label13.Size = new Size(125, 21);
            label13.TabIndex = 44;
            label13.Text = "New privilege ID";
            // 
            // legend
            // 
            legend.AutoSize = true;
            legend.Location = new Point(674, 169);
            legend.Name = "legend";
            legend.Size = new Size(143, 45);
            legend.TabIndex = 45;
            legend.Text = "Privilege group ID legend:\r\n2 - Manager.\r\n3 - Regular User.";
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(891, 572);
            Controls.Add(legend);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(modify_pgroup_button);
            Controls.Add(modify_ugroup_button);
            Controls.Add(new_pgroup_id);
            Controls.Add(userid_pg);
            Controls.Add(label4);
            Controls.Add(new_ugroup_id);
            Controls.Add(userid_ug);
            Controls.Add(delete_user_button);
            Controls.Add(userid);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(user_info_view);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label10);
            Controls.Add(logout_button);
            Controls.Add(back_button);
            Controls.Add(label9);
            Name = "Form5";
            Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)user_info_view).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label10;
        private Button logout_button;
        private Button back_button;
        private Label label9;
        private Label label8;
        private Label label7;
        private DataGridView user_info_view;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox userid;
        private Button delete_user_button;
        private TextBox userid_ug;
        private TextBox new_ugroup_id;
        private Label label4;
        private TextBox new_pgroup_id;
        private TextBox userid_pg;
        private Button modify_ugroup_button;
        private Button modify_pgroup_button;
        private Label label5;
        private Label label6;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label legend;
    }
}