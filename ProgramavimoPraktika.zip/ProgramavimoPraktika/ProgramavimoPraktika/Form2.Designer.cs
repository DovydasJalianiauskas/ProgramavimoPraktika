﻿namespace ProgramavimoPraktika
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            create_user_group_button = new Button();
            create_user_button = new Button();
            label1 = new Label();
            label2 = new Label();
            label10 = new Label();
            logout_button = new Button();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            modify_users_button = new Button();
            label3 = new Label();
            modify_services_button = new Button();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            check_button = new Button();
            SuspendLayout();
            // 
            // create_user_group_button
            // 
            create_user_group_button.Location = new Point(42, 237);
            create_user_group_button.Name = "create_user_group_button";
            create_user_group_button.Size = new Size(119, 44);
            create_user_group_button.TabIndex = 0;
            create_user_group_button.Text = "Create";
            create_user_group_button.UseVisualStyleBackColor = true;
            create_user_group_button.Click += create_user_group_button_Click;
            // 
            // create_user_button
            // 
            create_user_button.Location = new Point(240, 237);
            create_user_button.Name = "create_user_button";
            create_user_button.Size = new Size(119, 44);
            create_user_button.TabIndex = 1;
            create_user_button.Text = "Create";
            create_user_button.UseVisualStyleBackColor = true;
            create_user_button.Click += create_user_button_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(27, 180);
            label1.Name = "label1";
            label1.Size = new Size(158, 21);
            label1.TabIndex = 3;
            label1.Text = "Modify user groups";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(221, 180);
            label2.Name = "label2";
            label2.Size = new Size(157, 21);
            label2.TabIndex = 4;
            label2.Text = "Register a new user";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(70, 17);
            label10.Name = "label10";
            label10.Size = new Size(600, 25);
            label10.TabIndex = 20;
            label10.Text = "Service Tax System - everything in one place for your convenience";
            // 
            // logout_button
            // 
            logout_button.Location = new Point(745, 9);
            logout_button.Name = "logout_button";
            logout_button.Size = new Size(113, 47);
            logout_button.TabIndex = 19;
            logout_button.Text = "Log out";
            logout_button.UseVisualStyleBackColor = true;
            logout_button.Click += logout_button_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(-63, 55);
            label9.Name = "label9";
            label9.Size = new Size(1067, 15);
            label9.TabIndex = 17;
            label9.Text = resources.GetString("label9.Text");
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(36, 373);
            label8.Name = "label8";
            label8.Size = new Size(177, 15);
            label8.TabIndex = 22;
            label8.Text = "System is owned by StudentsTM";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(-11, 342);
            label7.Name = "label7";
            label7.Size = new Size(1067, 15);
            label7.TabIndex = 21;
            label7.Text = resources.GetString("label7.Text");
            // 
            // modify_users_button
            // 
            modify_users_button.Location = new Point(431, 237);
            modify_users_button.Name = "modify_users_button";
            modify_users_button.Size = new Size(119, 44);
            modify_users_button.TabIndex = 23;
            modify_users_button.Text = "Modify";
            modify_users_button.UseVisualStyleBackColor = true;
            modify_users_button.Click += modify_users_button_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(399, 180);
            label3.Name = "label3";
            label3.Size = new Size(197, 21);
            label3.TabIndex = 24;
            label3.Text = "Modify user information";
            // 
            // modify_services_button
            // 
            modify_services_button.Location = new Point(624, 237);
            modify_services_button.Name = "modify_services_button";
            modify_services_button.Size = new Size(119, 44);
            modify_services_button.TabIndex = 25;
            modify_services_button.Text = "Modify";
            modify_services_button.UseVisualStyleBackColor = true;
            modify_services_button.Click += modify_services_button_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(618, 180);
            label4.Name = "label4";
            label4.Size = new Size(130, 21);
            label4.TabIndex = 26;
            label4.Text = "Modify services";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(269, 92);
            label5.Name = "label5";
            label5.Size = new Size(451, 50);
            label5.TabIndex = 27;
            label5.Text = "Welcome!\r\nPlease select the proper action you want to perform.";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(800, 180);
            label6.Name = "label6";
            label6.Size = new Size(121, 21);
            label6.TabIndex = 28;
            label6.Text = "Check services";
            // 
            // check_button
            // 
            check_button.Location = new Point(802, 237);
            check_button.Name = "check_button";
            check_button.Size = new Size(119, 44);
            check_button.TabIndex = 29;
            check_button.Text = "Check";
            check_button.UseVisualStyleBackColor = true;
            check_button.Click += check_button_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(970, 413);
            Controls.Add(check_button);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(modify_services_button);
            Controls.Add(label3);
            Controls.Add(modify_users_button);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label10);
            Controls.Add(logout_button);
            Controls.Add(label9);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(create_user_button);
            Controls.Add(create_user_group_button);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button create_user_group_button;
        private Button create_user_button;
        private Label label1;
        private Label label2;
        private Label label10;
        private Button logout_button;
        private Label label9;
        private Label label8;
        private Label label7;
        private Button modify_users_button;
        private Label label3;
        private Button modify_services_button;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button check_button;
    }
}