﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgramavimoPraktika
{
    public partial class Form5 : Form
    {
        private int privilege;
        private int userGroupID;
        private string connectionString = "Server=localhost;Database=programavimopraktika;User ID=root;Password=";

        public Form5(int userGroupID, int privilege)
        {
            InitializeComponent();
            LoadUserData();
            this.privilege = privilege;
            this.userGroupID = userGroupID;
            delete_user_button.Enabled = privilege == 1;
            modify_pgroup_button.Enabled = privilege == 1;
        }

        private void delete_user_button_Click(object sender, EventArgs e)
        {
            string userIdString = userid.Text;
            if (string.IsNullOrEmpty(userIdString))
            {
                MessageBox.Show("User ID must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(userIdString, out int userId))
            {
                MessageBox.Show("Invalid User ID. It must be a numeric value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (userId == 1)
            {
                MessageBox.Show("Deleting the administrator user is not allowed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!UserIDExists(userId))
            {
                MessageBox.Show("User ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this user?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DeleteUser(userId);


                LoadUserData();

                MessageBox.Show("User deleted successfully!");
            }
        }

        private void modify_ugroup_button_Click(object sender, EventArgs e)
        {
            string userIdString = userid_ug.Text;
            string newUGroupIdString = new_ugroup_id.Text;

            if (string.IsNullOrEmpty(userIdString) || string.IsNullOrEmpty(newUGroupIdString))
            {
                MessageBox.Show("User ID and New User Group ID must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(userIdString, out int userId) || !int.TryParse(newUGroupIdString, out int newUGroupId))
            {
                MessageBox.Show("Invalid User ID or New User Group ID. They must be numeric values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (!UserIDExists(userId))
            {
                MessageBox.Show("User ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!UserGroupIDExists(newUGroupId))
            {
                MessageBox.Show("New User Group ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (CurrentUserGroupID(userId) == newUGroupId)
            {
                MessageBox.Show("New User Group ID should be different from the current User Group ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to modify the User Group ID?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                ModifyUserGroupID(userId, newUGroupId);

                LoadUserData();

                MessageBox.Show("User Group ID modified successfully!");
            }
        }

        private void modify_pgroup_button_Click(object sender, EventArgs e)
        {
            string userIdString = userid_pg.Text;
            string newPGroupIdString = new_pgroup_id.Text;

            if (string.IsNullOrEmpty(userIdString) || string.IsNullOrEmpty(newPGroupIdString))
            {
                MessageBox.Show("User ID and New Privilege Group ID must be filled.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(userIdString, out int userId) || !int.TryParse(newPGroupIdString, out int newPGroupId))
            {
                MessageBox.Show("Invalid User ID or New Privilege Group ID. They must be numeric values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!UserIDExists(userId))
            {
                MessageBox.Show("User ID does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (newPGroupId != 2 && newPGroupId != 3)
            {
                MessageBox.Show("New Privilege Group ID should be either 2 or 3.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (CurrentPrivilegeGroupID(userId) == newPGroupId)
            {
                MessageBox.Show("New Privilege Group ID should be different from the current Privilege Group ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to modify the Privilege Group ID?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                ModifyPrivilegeGroupID(userId, newPGroupId);
                LoadUserData();
                MessageBox.Show("Privilege Group ID modified successfully!");
            }
        }
        private void LoadUserData()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT * FROM users";
                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                        {
                            DataTable usersTable = new DataTable();
                            adapter.Fill(usersTable);

                            user_info_view.DataSource = usersTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private bool UserIDExists(int userId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM users WHERE UserID = @UserID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private void DeleteUser(int userId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM users WHERE UserID = @UserID";
                using (MySqlCommand deleteCommand = new MySqlCommand(deleteQuery, connection))
                {
                    deleteCommand.Parameters.AddWithValue("@UserID", userId);
                    deleteCommand.ExecuteNonQuery();
                }

                string deleteServicesQuery = "DELETE FROM users WHERE UserID = @UserID";
                using (MySqlCommand deleteServicesCommand = new MySqlCommand(deleteServicesQuery, connection))
                {
                    deleteServicesCommand.Parameters.AddWithValue("@UserID", userId);
                    deleteServicesCommand.ExecuteNonQuery();
                }
            }
        }

        private bool UserGroupIDExists(int userGroupId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM usergroups WHERE UserGroupID = @UserGroupID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserGroupID", userGroupId);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
        }

        private int CurrentUserGroupID(int userId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT UserGroupID FROM users WHERE UserID = @UserID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        private void ModifyUserGroupID(int userId, int newUserGroupId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "UPDATE users SET UserGroupID = @NewUserGroupID WHERE UserID = @UserID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NewUserGroupID", newUserGroupId);
                    command.Parameters.AddWithValue("@UserID", userId);
                    command.ExecuteNonQuery();
                }
            }
        }

        private int CurrentPrivilegeGroupID(int userId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT Privilege FROM users WHERE UserID = @UserID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        private void ModifyPrivilegeGroupID(int userId, int newPrivilegeGroupId)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = "UPDATE users SET Privilege = @NewPrivilegeGroupID WHERE UserID = @UserID";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@NewPrivilegeGroupID", newPrivilegeGroupId);
                    command.Parameters.AddWithValue("@UserID", userId);
                    command.ExecuteNonQuery();
                }
            }
        }

        private void logout_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(userGroupID, privilege);
            form2.Show();
            this.Close();
        }
    }
}
